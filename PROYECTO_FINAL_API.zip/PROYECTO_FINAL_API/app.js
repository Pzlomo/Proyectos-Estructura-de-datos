const express = require('express');
const app = express();
const itemsRoutes = require('./routes/items');

app.use(express.json());
app.use('/api/items', itemsRoutes);

app.listen(3000, () => {
    console.log("Servidor corriendo en http://localhost:3000");
});