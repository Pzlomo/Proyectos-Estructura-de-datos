let items = [ { id: 1, nombre: "Laptop", precio: 1500 } ];

exports.getItems = (req, res) => { res.status(200).json(items); };

exports.createItem = (req, res) => {
    const { nombre, precio } = req.body;
    if (!nombre || !precio) return res.status(400).json({ error: "Faltan datos" });
    const newItem = { id: items.length + 1, nombre, precio };
    items.push(newItem);
    res.status(201).json(newItem);
};

exports.updateItem = (req, res) => {
    const item = items.find(i => i.id == req.params.id);
    if (!item) return res.status(404).json({ error: "No encontrado" });
    item.nombre = req.body.nombre || item.nombre;
    item.precio = req.body.precio || item.precio;
    res.status(200).json(item);
};

exports.deleteItem = (req, res) => {
    const index = items.findIndex(i => i.id == req.params.id);
    if (index === -1) return res.status(404).json({ error: "No encontrado" });
    items.splice(index, 1);
    res.status(200).json({ mensaje: "Eliminado" });
};

exports.simularError = (req, res) => {
    try {
        // Simulamos una operación que falla (ejejmplo base de datos caida)
        throw new Error("Fallo crítico en el servidor");
    } catch (error) {
        // Aquí cumplimos el requisito del Código 500
        res.status(500).json({ error: "Error interno del servidor", detalle: error.message });
    }
};